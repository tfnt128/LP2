﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        private double num1, num2, resultado;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtNum1.Text, out num1))
            {
                errorProvider1.SetError(txtNum1, "Numero 1 inválido");
                txtNum1.Focus();
            }
            else
                errorProvider1.SetError(txtNum1, "");
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                num2 = Convert.ToDouble(txtNum2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtNum2, "Numero 2 inválido");
                txtNum2.Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            ResultadoCalc();
        }

        private void btnSubt_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            ResultadoCalc();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            ResultadoCalc();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Não pode ser divisivel por Zero", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Clear();
                txtNum2.Focus();
            }        
            else
                resultado = num1 / num2;

            ResultadoCalc();     
        }

        private void ResultadoCalc()
        {
            txtResult.Text = resultado.ToString();
        }

        private void ClearAll()
        {
            num1 = 0;
            num2 = 0;
            resultado = 0;

            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Voce quer sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
    }
}
