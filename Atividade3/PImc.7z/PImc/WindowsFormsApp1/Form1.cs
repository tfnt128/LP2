﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private double peso, altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            var imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            string tipoIMC;

            if (imc < 18)
                tipoIMC = "Abaixo do peso";
            else if (imc >= 18 && imc < 25)
                tipoIMC = "Peso Normal";
            else if (imc >= 25 && imc < 30)
                tipoIMC = "Sobrepeso";
            else if (imc >= 30 && imc < 35)
                tipoIMC = "Obesidade";
            else
                tipoIMC = "Obesidade severa";

                txtIMC.Text = imc.ToString("F1") + " = " + tipoIMC;
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("Peso Inválido");
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura Inválida");
                mskbxAltura.Focus();
            }
        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            peso = 0;
            altura = 0;

            mskbxAltura.Clear();
            mskbxPeso.Clear();  
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
