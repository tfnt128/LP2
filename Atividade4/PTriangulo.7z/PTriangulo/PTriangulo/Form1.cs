﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        private double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC)
                && ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC)
                && ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
            {
                if (ladoA == ladoB && ladoA == ladoC)
                    MessageBox.Show("É um triângulo equilátero");
                else if (ladoA == ladoB && ladoA != ladoC || ladoB == ladoC && ladoB != ladoA || ladoA == ladoC && ladoA != ladoB)
                    MessageBox.Show("É um triângulo isósceles");
                else
                    MessageBox.Show("É um triângulo escaleno");
            }
            else
                MessageBox.Show("Não é um triângulo");

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Lado A inválido");
                txtLadoA.Focus();
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Lado B inválido");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Lado C inválido");
                txtLadoC.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            ladoA = 0;
            ladoB = 0;
            ladoC = 0;

            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }
    }
}
