﻿namespace PMenu
{
    partial class Exercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContarNum = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.btnWhiteSpace = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxtFrase
            // 
            this.rchTxtFrase.Location = new System.Drawing.Point(318, 36);
            this.rchTxtFrase.Name = "rchTxtFrase";
            this.rchTxtFrase.Size = new System.Drawing.Size(165, 116);
            this.rchTxtFrase.TabIndex = 0;
            this.rchTxtFrase.Text = "";
            // 
            // btnContarNum
            // 
            this.btnContarNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContarNum.Location = new System.Drawing.Point(93, 275);
            this.btnContarNum.Name = "btnContarNum";
            this.btnContarNum.Size = new System.Drawing.Size(165, 88);
            this.btnContarNum.TabIndex = 1;
            this.btnContarNum.Text = "Contar números";
            this.btnContarNum.UseVisualStyleBackColor = true;
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContarLetras.Location = new System.Drawing.Point(318, 275);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(165, 88);
            this.btnContarLetras.TabIndex = 2;
            this.btnContarLetras.Text = "Contar letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            // 
            // btnWhiteSpace
            // 
            this.btnWhiteSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWhiteSpace.Location = new System.Drawing.Point(543, 275);
            this.btnWhiteSpace.Name = "btnWhiteSpace";
            this.btnWhiteSpace.Size = new System.Drawing.Size(165, 88);
            this.btnWhiteSpace.TabIndex = 3;
            this.btnWhiteSpace.Text = "Primeiro Caracter branco";
            this.btnWhiteSpace.UseVisualStyleBackColor = true;
            // 
            // Exercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnWhiteSpace);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnContarNum);
            this.Controls.Add(this.rchTxtFrase);
            this.Name = "Exercício4";
            this.Text = "Exercício4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtFrase;
        private System.Windows.Forms.Button btnContarNum;
        private System.Windows.Forms.Button btnContarLetras;
        private System.Windows.Forms.Button btnWhiteSpace;
    }
}