﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("chamou opção copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("chamou opção colar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<Exercício2>().Count() > 0)
            {
                MessageBox.Show("Forms já existe");
                Application.OpenForms["Exercício2"].BringToFront();
            }
            else
            {
                Exercício2 obj = new Exercício2();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }          
        }

        private void exercícioToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercício3>().Count() > 0)
            {
                MessageBox.Show("Forms já existe");
                Application.OpenForms["Exercício3"].BringToFront();
            }
            else
            {
                Exercício3 obj = new Exercício3();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }
        }

        private void exercícioToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercício4>().Count() > 0)
            {
                MessageBox.Show("Forms já existe");
                Application.OpenForms["Exercício4"].BringToFront();
            }
            else
            {
                Exercício4 obj = new Exercício4();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercício5>().Count() > 0)
            {
                MessageBox.Show("Forms já existe");
                Application.OpenForms["Exercício5"].BringToFront();
            }
            else
            {
                Exercício5 obj = new Exercício5();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }
        }
    }
}
