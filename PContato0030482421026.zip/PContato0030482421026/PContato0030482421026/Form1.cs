﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482421026
{
    

    public partial class frmPrincipal : Form

    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=BD;User ID=BD2421026;Password=Thiago134");
                conexao.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao abrir banco de dados" + ex.Message);

            }

        }

    }
}
